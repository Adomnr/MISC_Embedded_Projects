# digital-systems
 Repository with all the codes made during the learning offered by the discipline of Data Structure, from the degree of Computer Engineering at [Universidade Estadual do Rio Grande do Sul](https://www.uergs.edu.br/inicial).
